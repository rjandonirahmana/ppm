//! web/app.rs — Shell HTML (SSR) + komponen root `App` + tabel route.
//!
//! Design system "Islamic Institutional" (emerald + Work Sans, Material 3).
//! Tailwind di-SELF-HOST: di-compile cargo-leptos dari `style/tailwind.css`
//! (+ `tailwind.config.js`) → `/pkg/ppm.css` (statis), di-`<link>` di shell.
//! Bukan lagi Play CDN (tak ada compile Tailwind di browser).

use leptos::prelude::*;
use leptos_meta::{provide_meta_context, MetaTags, Title};
use leptos_router::{
    components::{FlatRoutes, Route, Router},
    path,
};

use crate::web::api::get_session;
use crate::web::components::{BottomNav, DesktopSidebar};
use crate::web::pages::*;


/// Shell HTML — dipanggil Axum untuk tiap SSR request.
pub fn shell(options: leptos::config::LeptosOptions) -> impl IntoView {
    view! {
        <!DOCTYPE html>
        <html lang="id" class="light">
            <head>
                <meta charset="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <meta name="theme-color" content="#003527" />

                // ── CSS: Tailwind self-host (di-compile cargo-leptos → statis) ──
                // Ganti Play CDN: tanpa compile Tailwind di browser. Tema & CSS
                // kustom ada di style/tailwind.css + tailwind.config.js.
                <link rel="stylesheet" href="/pkg/ppm.css" />

                // ── Interaktivitas: scroll-reveal + count-up angka ───────────
                // 1) Tandai <html> reveal-js SINKRON → [data-reveal] hanya
                //    disembunyikan saat JS aktif (tanpa JS konten tetap tampil).
                <script inner_html="document.documentElement.classList.add('reveal-js');"></script>
                // 2) IntersectionObserver utk [data-reveal]; count-up utk
                //    [data-count] (angka naik 0→target saat terlihat).
                //    MutationObserver menangkap konten Suspense/SPA. Guard
                //    data-counted mencegah loop (mutasi textContent sendiri).
                <script inner_html=r#"
(function(){
  if(window.__ppmFx) return; window.__ppmFx=true;
  /* bfcache: halaman yang dipulihkan tombol Back masih memegang state sesi
     LAMA (mis. setelah logout) → muat ulang agar cookie dicek kembali.
     Tanpa ini logout tampak "gagal" saat user menekan Back. */
  window.addEventListener('pageshow',function(e){ if(e.persisted) location.reload(); });
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function countUp(el){
    if(el.getAttribute('data-counted')==='1') return;
    el.setAttribute('data-counted','1');
    var target=parseInt(el.getAttribute('data-count'),10);
    if(isNaN(target)||reduce){ return; }
    var dur=700, t0=null;
    function step(t){
      if(!t0) t0=t;
      var p=Math.min((t-t0)/dur,1);
      p=1-Math.pow(1-p,3); /* ease-out */
      el.textContent=Math.round(target*p);
      if(p<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  var io=('IntersectionObserver' in window)?new IntersectionObserver(function(es){
    es.forEach(function(e){
      if(!e.isIntersecting) return;
      if(e.target.hasAttribute('data-reveal')) e.target.classList.add('is-visible');
      if(e.target.hasAttribute('data-count')) countUp(e.target);
      io.unobserve(e.target);
    });
  },{threshold:0.15}):null;
  function scan(){
    document.querySelectorAll('[data-reveal]:not([data-fx]),[data-count]:not([data-fx])')
      .forEach(function(el){
        el.setAttribute('data-fx','1');
        if(io){ io.observe(el); }
        else { el.classList.add('is-visible'); if(el.hasAttribute('data-count')) countUp(el); }
      });
  }
  function start(){
    scan();
    try{ new MutationObserver(function(){ scan(); })
      .observe(document.body,{childList:true,subtree:true}); }catch(e){}
    /* Pengaman: tampilkan semua reveal setelah 5 dtk apa pun yang terjadi. */
    setTimeout(function(){
      document.querySelectorAll('[data-reveal]').forEach(function(el){el.classList.add('is-visible');});
    },5000);
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded',start); }
  else { start(); }
})();
"#></script>

                // ── Ikon Material Symbols: SELF-HOST lokal (public/fonts, ~28KB) ──
                // Tak lagi dari Google CDN. Preload agar diunduh dini (dipakai di
                // hampir semua halaman). @font-face ada di /pkg/ppm.css.
                <link
                    rel="preload"
                    href="/fonts/material-symbols.woff2"
                    attr:as="font"
                    r#type="font/woff2"
                    crossorigin=""
                />
                // ── Work Sans (teks) masih dari CDN (degradasi mulus ke system font).
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="" />
                <link
                    href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;500;600;700&display=swap"
                    rel="stylesheet"
                />

                <AutoReload options=options.clone() />
                <HydrationScripts options />
                <MetaTags />
            </head>
            <body class="bg-surface text-on-surface">
                <App />
            </body>
        </html>
    }
}

/// Komponen root — universal SSR + hydration.
#[component]
pub fn App() -> impl IntoView {
    provide_meta_context();

    // Sesi GLOBAL (role) — dibaca oleh <BottomNav/> yang persisten. Blocking agar
    // role sudah ada di HTML SSR (navbar benar sejak awal, tanpa kedip). Di-cache
    // (key `()`), jadi tak refetch saat pindah halaman → navbar tak berubah.
    let session = Resource::new_blocking(|| (), |_| async move { get_session().await.ok().flatten() });
    provide_context(session);

    view! {
        <Title text="PPM AFM — Portal Absensi Santri" />
        <Router>
            <FlatRoutes fallback=|| view! { <NotFoundPage /> }>
                // Publik: beranda profil pesantren untuk pengunjung.
                <Route path=path!("/") view=BerandaPage />
                <Route path=path!("/login") view=LoginPage />
                <Route path=path!("/menu") view=MenuPage />

                // Santri (dinamis — data DB)
                <Route path=path!("/santri") view=SantriDashboardPage />
                <Route path=path!("/izin") view=IzinPage />
                <Route path=path!("/riwayat") view=RiwayatPage />
                <Route path=path!("/sesi") view=SesiPage />
                <Route path=path!("/sesi/:id") view=SesiDetailPage />
                <Route path=path!("/sesi/:id/live") view=SesiLivePage />
                <Route path=path!("/profil") view=ProfilPage />
                <Route path=path!("/laporan") view=LaporanPage />

                // Staf / Guru / Dewan Guru
                <Route path=path!("/staf") view=StafDashboardPage />
                <Route path=path!("/guru") view=GuruDashboardPage />
                <Route path=path!("/dewan-guru") view=DewanGuruDashboardPage />
                <Route path=path!("/poin") view=PoinPage />
                <Route path=path!("/poin-dewan") view=PoinDewanPage />
                <Route path=path!("/verifikasi-pamong") view=VerifikasiPamongPage />
                <Route path=path!("/verifikasi-tahap-2") view=VerifikasiTahap2Page />
                <Route path=path!("/students") view=StudentsPage />
                <Route path=path!("/kelas") view=KelasPage />
                <Route path=path!("/kelas/:id") view=KelasDetailPage />

                // Halaqah
                <Route path=path!("/halaqah") view=HalaqahDaftarPage />
                <Route path=path!("/halaqah/mulai") view=HalaqahMulaiPage />
                <Route path=path!("/halaqah/live") view=HalaqahLivePage />
                <Route path=path!("/rekaman") view=RekamanPage />

                // Orang tua (dinamis — data DB, koneksi butuh approval santri)
                <Route path=path!("/orang-tua") view=OrtuBerandaPage />
                <Route path=path!("/orang-tua/izin") view=OrtuIzinPage />
                <Route path=path!("/orang-tua/riwayat") view=OrtuRiwayatPage />
                <Route path=path!("/koneksi-ortu") view=KoneksiOrtuPage />
            </FlatRoutes>
            // Navbar bawah PERSISTEN — di luar <FlatRoutes> agar tak ikut
            // ter-swap/shimmer saat pindah halaman (hanya konten yang shimmer).
            <BottomNav />
            <DesktopSidebar />
        </Router>
    }
}
