//! config.rs — Konfigurasi aplikasi + pool Postgres (server-only).

use anyhow::{Context, Result};
use deadpool_postgres::{Config as PgConfig, Pool, PoolConfig, Runtime};
use std::env;
use tokio_postgres::NoTls;

pub struct AppConfig {
    pub host: String,
    pub port: u16,
    pub database_url: String,
    pub db_pool_max_size: usize,
    pub jwt_secret: String,
    /// RustFS (S3-compatible) untuk rekaman siaran — None = simpan lokal saja.
    pub rustfs: Option<RustFsConfig>,
    /// Redis: link undangan registrasi (24 jam) + pending registration/OTP
    /// (10 menit). WAJIB (fail-fast) — tak ada mode "nonaktif" yang masuk akal
    /// utk fitur yang inti kerjanya menyimpan kode OTP sementara.
    pub redis_url: String,
    pub waha: WahaConfig,
}

/// WAHA (WhatsApp HTTP API) — kirim OTP + password registrasi lewat WA.
/// Pola sama e-ticketing: base_url + session + api_key opsional.
pub struct WahaConfig {
    pub base_url: String,
    pub session: String,
    pub api_key: String,
}

/// Kredensial RustFS (pola e-ticketing/wedding-web). Aktif bila RUSTFS_ENDPOINT
/// di-set. Bucket default "ppm" (bucket sendiri); key tetap berprefix `ppm/...`.
pub struct RustFsConfig {
    pub endpoint: String,
    pub access_key: String,
    pub secret_key: String,
    pub bucket: String,
    pub public_url: String,
}

impl AppConfig {
    pub fn from_env() -> Result<Self> {
        Ok(Self {
            host: env::var("HOST").unwrap_or_else(|_| "0.0.0.0".into()),
            port: env::var("PORT")
                .ok()
                .and_then(|p| p.parse().ok())
                .unwrap_or(3000),
            database_url: env::var("DATABASE_URL")
                .unwrap_or_else(|_| "dev-secret-ubah-di-prod".into()),
            // Default 8 (bukan 16): VPS 2 CPU/4GB — hemat memori (audit Jul 2026).
            db_pool_max_size: env::var("DB_POOL_MAX_SIZE")
                .ok()
                .and_then(|p| p.parse().ok())
                .unwrap_or(8),
            jwt_secret: env::var("JWT_SECRET").unwrap_or_else(|_| "dev-secret-ubah-di-prod".into()),
            rustfs: match env::var("RUSTFS_ENDPOINT") {
                Ok(endpoint) => Some(RustFsConfig {
                    endpoint,
                    access_key: env::var("RUSTFS_ACCESS_KEY")
                        .context("RUSTFS_ACCESS_KEY wajib bila RUSTFS_ENDPOINT di-set")?,
                    secret_key: env::var("RUSTFS_SECRET_KEY")
                        .context("RUSTFS_SECRET_KEY wajib bila RUSTFS_ENDPOINT di-set")?,
                    bucket: env::var("RUSTFS_BUCKET").unwrap_or_else(|_| "ppm".into()),
                    public_url: env::var("RUSTFS_PUBLIC_URL")
                        .context("RUSTFS_PUBLIC_URL wajib bila RUSTFS_ENDPOINT di-set")?,
                }),
                Err(_) => None,
            },
            redis_url: env::var("REDIS_URL").context("REDIS_URL wajib diset (registrasi+OTP)")?,
            waha: WahaConfig {
                base_url: env::var("WAHA_BASE_URL").unwrap_or_else(|_| "http://localhost:3000".into()),
                session: env::var("WAHA_SESSION").unwrap_or_else(|_| "default".into()),
                api_key: env::var("WAHA_API_KEY").unwrap_or_default(),
            },
        })
    }
}

/// Buat pool Postgres + verifikasi koneksi awal (fail-fast bila DB mati).
pub async fn create_pool(database_url: &str, max_size: usize) -> Result<Pool> {
    let mut cfg = PgConfig::new();
    cfg.url = Some(database_url.to_string());
    cfg.pool = Some(PoolConfig::new(max_size));
    let pool = cfg
        .create_pool(Some(Runtime::Tokio1), NoTls)
        .context("gagal membuat pool Postgres")?;
    let _ = pool.get().await.context("koneksi awal ke Postgres gagal")?;
    Ok(pool)
}
